#include<bits/stdc++.h>
using namespace std;
map<char,int>p;
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int t; cin >> t;
    while(t--){
    p['^'] = 3;
    p['*'] = 2;
    p['/'] = 2;
    p['+'] = 1;
    p['-'] = 1;
    p['('] = 0;
    p[')'] = 0;

    string s; cin >> s;
    stack<char>st;
    string postfix;
    char x;
    reverse(s.begin(), s.end());
    int ln = s.size();
    for(int i=0; i<ln; ++i)
    {
        if(isdigit(s[i]) || isalpha(s[i])){
            postfix += s[i];
            continue;
        }
        if(st.empty()) st.push(s[i]);
        else{
            if(s[i] == ')'){
                st.push(s[i]);
                continue;
            }
            if(s[i] == '('){
                while(!st.empty()){
                x = st.top();
                st.pop();
                if(x == ')') break;
                postfix += x;
               }
               continue;
               }
               while(!st.empty()){
                x = st.top();
                if(p[x] == p[s[i]] || p[x] > p[s[i]]){
                    st.pop();
                    postfix += x;
                }
                else break;
               }
               st.push(s[i]);
        }
    }
    while(!st.empty()){
        postfix += x;
        st.pop();
    }
    reverse(postfix.begin(), postfix.end());
    cout << postfix << endl;
    }
    return 0;
}
