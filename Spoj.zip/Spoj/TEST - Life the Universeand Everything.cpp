#include<bits/stdc++.h>
using namespace std;

int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    vector<int>v;
    while(1)
    {
        int x; cin >> x;

        if(x > 99 || x==42) {
            break;
        }
        cout << x << endl;
    }

    return 0;
}
