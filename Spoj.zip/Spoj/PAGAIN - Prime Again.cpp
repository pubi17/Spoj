
#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long int ll;
int main(){
	ll n=2e32;


	bool sieve[n+1];

	//sieve of eratosthenes
	memset(sieve,true,sizeof(sieve));//initially all true
	sieve[0]=sieve[1]=false;//0,1 not prime
	for(ll i=2;i*i<=n;i++)
		if(sieve[i])
	for(ll j=i*2;j<=n;j+=i)//for multiple of i
		sieve[j]=false;//can't be prime



	int t;
	cin>>t;

	while(t--){
	    ll a; cin >> a;

    for(ll k=a-1; k>=3; k--)

		if(sieve[k]){
			cout<<k<<endl; break;}

	}

	return 0;
}
